﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsRover
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Rover rover1 = new Rover("1 2 N");
            rover.Move("LMLMLMLMM");
            Console.Write("Output is:");
            Console.Write(rover1.xCoordinate+" ");
            Console.Write(rover1.yCoordinate+" ");
            Console.Write(rover1.direction);
            Console.WriteLine();
            Console.WriteLine();
            Rover rover2 = new Rover("3 3 E");
            rover2.Move("MMRMMRMRRM");
            Console.Write("Output is:");
            Console.Write(rover2.xCoordinate+ " ");
            Console.Write(rover2.yCoordinate+" ");
            Console.Write(rover2.direction);
            Console.WriteLine();
            Console.WriteLine();

        }
    }
}
