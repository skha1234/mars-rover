﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarsRover
{
    public class Rover
    {
        public int xCoordinate;
        public int yCoordinate;
        public string direction;

        public Rover(string location)
        {
            Int32.TryParse(location.Split(' ')[0], out xCoordinate);
            Int32.TryParse(location.Split(' ')[1], out yCoordinate);
            direction = location.Split(' ')[2];
       }

        public void SpinLeft()
        {
            switch (direction)
            {
                case "N":
                    direction = "W";
                    break;
                case "E":
                    direction = "N";
                    break;
                case "S":
                    direction = "E";
                    break;
                case "W":
                    direction = "S";
                    break;
                default:
                    throw new ArgumentException();
            }
        }
   
        public void SpinRight()
        {
            switch (direction)
            {
                case "N":
                    direction = "E";
                    break;
                case "E":
                    direction = "S";
                    break;
                case "S":
                    direction = "W";
                    break;
                case "W":
                    direction = "N";
                    break;
                default:
                    throw new ArgumentException();
            }
        }

        public void StepForward()
        {
            switch (direction)
            {
                case "N":
                    yCoordinate++;
                    break;
                case "E":
                    xCoordinate++;
                    break;
                case "S":
                    yCoordinate--;
                    break;
                case "W":
                    xCoordinate--;
                    break;
                default:
                    throw new ArgumentException();
            }
        }

        public void Move(string command)
        {
            char[] instructions = command.ToCharArray();
            for (int i= 0;i<instructions.Length;i++)
            {
                switch (instructions[i])
                {
                    case 'L':
                        SpinLeft();
                        break;
                    case 'R':
                        SpinRight();
                        break;
                    case 'M':
                        StepForward();
                        break;
                    default:
                        throw new ArgumentException();
                }
            }
        }

    }
}


