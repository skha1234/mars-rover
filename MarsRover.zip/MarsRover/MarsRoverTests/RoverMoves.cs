using System;
using Xunit;
using MarsRover;

namespace MarsRoverTests
{
    public class RoverMoves
    {
        [Fact]
        public void SpinLeft()
        {
            Rover rover = new Rover("1 2 N");
            rover.SpinLeft();
            Assert.Equal("W", rover.direction);
        }

        [Fact]
        public void SpinRight()
        {
            Rover rover = new Rover("1 2 N");
            rover.SpinRight();
            Assert.Equal("E", rover.direction);
        }

        [Fact]
        public void StepForward()
        {
            Rover rover = new Rover("1 2 N");
            rover.StepForward();
            Assert.Equal(3,rover.yCoordinate);
        }

        [Fact]
        public void Move()
        {
            Rover rover = new Rover("1 2 N");
            rover.Move("LMLMLMLMM");
            Assert.Equal("1 3 N", rover.xCoordinate+" "+ rover.yCoordinate+ " "+ rover.direction);
        }

    }
}
